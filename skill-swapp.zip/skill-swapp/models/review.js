// models/Review.js
const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const Review = sequelize.define("Review", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false }, // the one submitting
  targetUserId: { type: DataTypes.INTEGER, allowNull: true }, // optional: user being reviewed
  type: { 
    type: DataTypes.ENUM("complaint", "review", "bug"), 
    allowNull: false 
  },
  content: { type: DataTypes.TEXT, allowNull: false },
  status: { 
    type: DataTypes.ENUM("open", "resolved"), 
    defaultValue: "open" 
  }
});

module.exports = Review;