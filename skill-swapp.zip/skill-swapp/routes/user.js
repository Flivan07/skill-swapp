const express = require('express');
const jwt = require('jsonwebtoken');
const users = require('../models/users.js');
const router = express.Router();

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, "secret123");
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

router.get('/profile', authMiddleware, async (req, res) => {
  const user = await users.findByPk(req.user.id);
  res.json(user);
});

router.put('/profile', authMiddleware, async (req, res) => {
  const { username } = req.body;
  const user = await users.findByPk(req.user.id);
  user.username = username;
  
  await user.save();
  res.json(user);
});

module.exports = {router , authMiddleware} ;
