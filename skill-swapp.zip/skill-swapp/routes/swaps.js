const express = require('express');
const swap = require('../models/swap');
const router = express.Router();
const {authMiddleware} = require('./user');

router.post('/change', authMiddleware, async (req, res) => {
  const { receiverid, skilloffer, skillgiven } = req.body;
  const swaps = await swap.create({
    senderid: req.user.id,
    receiverid,
    skilloffer,
    skillgiven,
  });
  res.json(swaps);
});

router.get('/change', authMiddleware, async (req, res) => {
  const swaps = await swap.findAll({
    where: { senderid: req.user.id },
  });
  res.json(swaps);
});

module.exports = router;