const express = require("express");
const router = express.Router();
const { authMiddleware } = require("./user");
const review = require("../models/review");

// Create a review/complaint
router.post("/", authMiddleware, async (req, res) => {
  try {
    const { targetUserId, type, content } = req.body;
    const Review = await review.create({
      userId: req.user.id,
      targetUserId,
      type,
      content
    });
    res.json({ message: "Submitted successfully", Review });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to submit" });
  }
});

// Get my complaints/reviews
router.get("/my", authMiddleware, async (req, res) => {
  try {
    const Review = await review.findAll({ where: { userId: req.user.id } });
    res.json(Review);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch" });
  }
});