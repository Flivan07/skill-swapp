const express = require("express")
const sequelize = require("./config/database.js")
const authroutes = require("./routes/authentication.js")
const {router: userroutes} = require("./routes/user.js")
const swaproutes = require("./routes/swaps.js")
const app = express()

app.use(express.json())
app.use('/authentication', authroutes)
app.use('/user', userroutes)
app.use('/swaps', swaproutes)

sequelize.sync().then(() => {
  app.listen(3000, () => console.log('Server started on port 3000'));
});